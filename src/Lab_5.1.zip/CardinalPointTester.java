public class CardinalPointTester {
    public static void main(String[] args) {

        System.out.println("Idziesz w kierunku: " + CardinalPoints.NORTH.getEnglishName() + " ,skrót tego kierunku to: " + CardinalPoints.NORTH.getShortName() + " ,polska nazwa kierunku to: " + CardinalPoints.NORTH.getPolishName());
        System.out.println("Idziesz w kierunku: " + CardinalPoints.SOUTHEAST.getEnglishName() + " ,skrót tego kierunku to: " + CardinalPoints.SOUTHEAST.getShortName() + " ,polska nazwa kierunku to: " + CardinalPoints.SOUTHEAST.getPolishName());
    }
}
