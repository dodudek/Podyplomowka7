public class ComputationTester {
    public static void main(String[] args) {
        System.out.println(Computation.ADD.perform(4,8));
        System.out.println(Computation.DIVIDE.perform(20,2));
        System.out.println(Computation.MULTIPLAY.perform(6,-14));
        System.out.println(Computation.SUBTRACT.perform(9,5));
    }
}
