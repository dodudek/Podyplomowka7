public class NegativeNumberException extends Throwable {
    public NegativeNumberException()
    {
        super("Negative Number Exception!");
    }
}
